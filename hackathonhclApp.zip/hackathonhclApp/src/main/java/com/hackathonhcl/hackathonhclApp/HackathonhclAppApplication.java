package com.hackathonhcl.hackathonhclApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HackathonhclAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(HackathonhclAppApplication.class, args);
	}

}
